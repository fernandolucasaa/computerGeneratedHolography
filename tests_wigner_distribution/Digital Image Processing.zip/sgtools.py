"""
DIGITAL IMAGE PROCESSING PYTHON CODE
author: Salvador Gabarda
salvador@optica.csic.es

This script includes Python functions for digital image processing. Details and examples of application of this software may be found in

https://scholar.google.es/citations?user=jPzi3LEAAAAJ&hl=es&oi=ao

Created on Mar 23 2018, reviewed Dec 27 2019
"""
# import modules
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from scipy.fftpack import fft, ifft
import math
from scipy import signal
import matplotlib.mlab as mlab
import pandas as pd
from scipy import special
import matplotlib.patches as mpatches
from matplotlib import cm
from scipy import misc
from scipy import stats
#from PIL import Image
import imageio
import os
os.path
cwd = os.getcwd()


def oriented_pattern(seq_length,angle):
    """
    This function originates a pattern that is later used for the orientation of the operational pseudo-Wigner distribution
    computation window,     seq_length: sequence length in pixels,    angle: orientation in degrees.
    """
    angle = np.mod(angle,180)
    # correction to set axes in the image (x: rows, y: columns) to observer cartesian coordinates x,y
    angle = np.mod((angle+90),180)
    angle =math.radians(angle)
    pi = math.pi
    h = int((seq_length/2))
    values = np.r_[float(-h):float(h+1)]
    new_positions = np.zeros([2*h+1, 2])
    for position in range(seq_length):
        if angle >= 0 and angle < pi/4:
            new_positions[position,0] = values[position]+h
            new_positions[position,1] = values[position]*math.tan(angle)+h
        elif angle >= pi/4 and angle < pi/2:
            new_positions[position,0] = values[position]*math.tan(pi/2-angle)+h
            new_positions[position,1] = values[position]+h
        elif angle >= pi/2 and angle < 3*pi/4:
            new_positions[position,0] = values[position]*math.tan(pi/2-angle)+h
            new_positions[position,1] = values[position]+h
        elif angle >= 3*pi/4 and angle <= pi:
            new_positions[position,0] = 1*values[position]+h
            new_positions[position,1] = values[position]*math.tan(angle)+h
        new_points = np.round_(new_positions)
    return new_points.astype(int)

def image_arrangement (test_image,seq_length,angle,indices):
    """
    arrangement operation for time reduction
    """
    rows = test_image.shape[0]
    columns = test_image.shape[1]
    layers = np.zeros(((seq_length,rows,columns)))
    for k in range(seq_length):
        mask = np.zeros((seq_length,seq_length))
        mask[indices[k,0],indices[k,1]] = 1 
        layers[k,:,:] = signal.convolve2d(test_image, mask, boundary='symm', mode='same')
    return layers

def layer_product_function(layers,seq_length):
    """
    product function of the Wigner distribution
    """
    faces = layers.shape[0]
    rows =layers.shape[1]
    columns = layers.shape[2]
    layer_product = np.ones(((seq_length-1,rows,columns)))
    layers[faces-1,:,:]=layers[0,:,:]
    for i in range(faces-1):
        layer_product[i,:,:]= layers[i,:,:]*layers[faces-1-i]
    return layer_product

def layer_wigner_distribution(test_image,seq_length,angle):
    """
    Wigner distribution of test_image, seq_lengthe: odd number of pixels, e.g.: 9, angle: degrees, e.g.: 45
    """
    indices = oriented_pattern(seq_length,angle)
    layers = image_arrangement (test_image,seq_length,angle,indices)
    layer_product = layer_product_function(layers,seq_length)
    distribution = fft(layer_product, axis = 0)
    distribution = np.real(distribution)
    # set zero frequency in central position
    Head = distribution[int(seq_length/2):seq_length,:,:]
    Tail = distribution[0:int(seq_length/2),:,:]
    distribution = np.append(Head,Tail, axis = 0)
    return distribution

def renyi_entropy(distribution,order):
    """
    This function calculates the Rényi entropy of an image based on its pseudo-Wigner distribution (distribution). 
    The "order" variabe represents the exponential order of the Rényi entropy (3 is the most common value)
    """
    eps = np.finfo(float).eps
    rows = distribution.shape[1]
    columns = distribution.shape[2]
    layers = distribution.shape[0]
    squared_wl = np.ones([layers,rows,columns])
    for layer in range(layers):
        # square distribution local values
        working_layer = distribution[layer,:,:]
        squared_wl[layer,:,:] = np.multiply(working_layer,working_layer)
    squared_wd = squared_wl
    # sum squared wigner distribution along coordinate 1
    sum_sq_wd = np.sum(squared_wd, axis = 0)
    # normalize squared values
    normalized_distribution =np.zeros([layers,rows,columns])
    for layer in range(layers):
        normalized_distribution[layer,:,:] = np.divide(squared_wd[layer,:,:],sum_sq_wd+eps)
    # raise elements to the power defined by input variable "order"
    power_nor_dis = np.power(normalized_distribution,order)
    # sum pixelwise
    entropy_1 = np.sum(power_nor_dis, axis = 0)+eps
    # pixelwise entropy
    entropy_2 =np.log2(entropy_1)
    entropy =(1/(1-order))*entropy_2
    super_threshold_indices = entropy < 0
    entropy[super_threshold_indices] = 0
    entropy = np.nan_to_num(entropy)
    # normalize entropy
    #entropy = entropy*(1/np.log2(layers))
    return entropy

def show_wigner_frequencies(distribution):
    """
    Starting from the pseudo-Wigner distribution (distribution) of the input test image, this function gives a visualization
    of the frequency components of such distribution. Distributions' images are saved in pdf's. Note that a similar function,
    but that does not save images is "wigner_frequencies". 
    """
    rows = distribution.shape[1]
    columns = distribution.shape[2]
    layers = distribution.shape[0]
    frequencies = np.zeros([layers,rows,columns])
    for layer in range(layers):
        frequency = distribution[layer,:,:]
        min_val =np.amin(frequency)
        frequency = frequency - min_val
        max_val = np.amax(frequency)
        frequency = (1/max_val)*frequency
        #plt.figure()
        frequency = np.uint8(255*frequency)
        #plt.imshow(frequency, interpolation='nearest',cmap='gray')
        #plt.imshow(frequency,cmap='gray')
        name = "wigner_distribution_" + str(layer) + ".png"
        msg = "Wigner distribution, frequency #" + str(layer)
        #plt.axis('off')
        #plt.title(msg)
        np.reshape(frequency,(rows,columns))
        #mpimg.imsave(name,frequency,format = 'png',cmap = cm.gray)
        #frequency.save(name,"png")
        # Creates PIL image
        img = Image.fromarray( frequency , 'L')
        img.save(name,'png')
        #plt.savefig(name)
        frequencies[layer,:,:]= frequency
    return frequencies 

def layer_image_anisotropy(test_image,image_name,seq_length,orientations,order):
    """
    This function calculates a parameter that behaves as an objective measure of the quality of the image for Gaussian blur
    and Gaussian noise. It is based on the frequency content given by the pseudo-Wigner distribution. 
    """
    entropy_val = np.zeros([orientations])
    for orientation in range(orientations):
        angle = (180/orientations)*orientation
        print( angle, " degrees distribution")
        distribution = layer_wigner_distribution(test_image,seq_length,angle)
        entropy_pixelwise = renyi_entropy(distribution,order)
        entropy = np.mean(entropy_pixelwise)
        print("entropy is %.4f" % entropy)
        entropy_val[orientation] = entropy
    anisotropy = np.var(entropy_val)
    anisotropy = math.sqrt(anisotropy)
    print("\n")
    print("The AQI (image anisotropy) is %.4f" % anisotropy)
    print("\n")
    F = open("AQI test.txt","a")
    F.write(image_name)
    F.write("\n")
    F.write("The Anisotropic Quality Index of the image is %.4f\n" % anisotropy)
    F.close()
    return anisotropy

def input_test_image(subfolder,name):
    total_name = subfolder + name
    #print('loading image ',total_name)
    input_image = mpimg.imread(total_name) 
    image_dimension = len(input_image.shape)
    if image_dimension == 3:
        test_image = (1/3)*(input_image[:,:,0]+
                      input_image[:,:,1]+input_image[:,:,2])
    else:
        test_image = input_image
    
    # convert image to regular gray levels
    test_image = test_image / test_image.max() #normalizes data in range 0 - 255
    test_image = 255 * test_image
    test_image =np.uint8(test_image)
    return test_image

def mapfusion(subfolder,topic,number,mode): 
    # for images labeled:   topic.001.png, topic.002.png,... use mode 1
    # for images labeled:   1.png, 2.png,... use mode 2
    mask = np.array([[1, 4, 6, 4, 1],[4, 16, 24, 16, 4],[6, 24, 36, 24, 6],[4, 16, 24, 16, 4],[1, 4, 6, 4, 1]])
    mask = (1/256)*mask
    R = number
    name = topic
    for i in range(1,R+1):
        # input test image
        if mode == 1:
            if i < 10:
                series = "00"
            elif (i >= 10 and i < 100):
                series = "0"
            elif (i >= 100 and i < 1000):
                series = "" 
            image_name =  name + '.' + series + str(i) + '.png'
        elif mode == 2:
            image_name =  str(i) + '.png'
        print("processing image ",image_name)
        test_image = input_test_image(subfolder,image_name)
        if i == 1:
            img_shape = np.shape(test_image)
            rows = img_shape[0]
            columns = img_shape[1]
            stack = np.zeros(((R,rows,columns)))
            blur = np.zeros(((R,rows,columns)))
            stack[0,:,:] = test_image
            blur[0,:,:]= signal.convolve2d(test_image, mask, boundary='symm', mode='same')
        else:
            stack[i-1,:,:] = test_image
            blur[i-1,:,:]= signal.convolve2d(test_image, mask, boundary='symm', mode='same')
        
    blur = np.sum(blur,0)
    blur = (1/R)*blur

    # convert image to regular gray levels 
    blur =np.uint8(blur)

    # show blurred image
    plt.figure(figsize =(6,6))
    plt.imshow(blur, cmap='gray')
    plt.xlabel("worst case image")
    savename = subfolder + "worst_case_1" +  ".png"
    imageio.imwrite(savename,blur)
    #savename = "worst_case" +  ".pdf"
    #plt.savefig(savename)
    plt.show()

    seq_length = 9
    angle = 0
    
    wigner_blur = layer_wigner_distribution(blur,seq_length,angle)
    #wigner_blur = np.zeros(((seq_length-1,rows,columns))) # option with a zero  worst case image as reference
    wigner_stack = np.zeros(((R,rows,columns)))
    norm = np.zeros(((R,rows,columns)))
    for i in range(R):
        stack_copy = np.copy(stack[i,:,:])
        wigner = layer_wigner_distribution(stack_copy,seq_length,angle)
        diff = np.subtract(wigner_blur,wigner)
        diff = np.square(diff)
        norm[i,:,:] = np.sum(diff,axis = 0)
    mapa = np.argmax(norm,0)

    # show decision map
    max_map = np.amax(mapa)
    dmap = (1/max_map)*255*mapa
    dmap = np.uint8(dmap)
    plt.figure(figsize =(6,6))
    plt.imshow(dmap, cmap='gray')
    plt.xlabel("decision map")
    savename = subfolder + "decision_map_1" +  ".png"
    imageio.imwrite(savename,dmap)
    plt.show()

    fusion = np.zeros((rows,columns))
    for i in range(R):
        stack_copy = np.copy(stack[i,:,:])
        factor = mapa == i
        fusion = fusion + np.multiply(factor,stack_copy)
    
    # show fusion
    plt.figure(figsize =(6,6))
    fusion = np.uint8(fusion)
    plt.imshow(fusion, cmap='gray')
    plt.xlabel("fusion")
    savename = subfolder + "fusion_1" +  ".png"
    imageio.imwrite(savename,fusion)
    plt.show()
    
    return blur, mapa, fusion

def maxentropyfusion(subfolder,topic,number,mode):
    # for images labeled:   topic.001.png, topic.002.png,... use mode 1
    # for images labeled:   1.png, 2.png,... use mode 2
    R = number
    name = topic
            
    for i in range(1,R+1):
        if mode == 1:
            if i < 10:
                series = "00"
            elif (i >= 10 and i < 100):
                series = "0"
            elif (i >= 100 and i < 1000):
                series = "" 
            image_name =  name + '.' + series + str(i) + '.png'
        elif mode == 2:
            image_name =  str(i) + '.png'
        
        print("processing image ",image_name)
        test_image = input_test_image(subfolder,image_name)
        if i == 1:
            img_shape = np.shape(test_image)
            rows = img_shape[0]
            columns = img_shape[1]
            stack = np.zeros(((R,rows,columns)))
            stack[0,:,:] = test_image
            
        else:
            stack[i-1,:,:] = test_image
            
        
   
    seq_length = 9
    angle = 0

    entropy = np.zeros(((R,rows,columns)))
    for i in range(R):
        stack_copy = np.copy(stack[i,:,:])
        wigner = layer_wigner_distribution(stack_copy,seq_length,angle)
        entropy[i,:,:] = renyi_entropy(wigner,3)
        
    mapa = np.argmax(entropy,0)
    
    # show decision map
    max_map = np.amax(mapa)
    dmap = (1/max_map)*255*mapa
    dmap = np.uint8(dmap)
    plt.figure(figsize =(6,6))
    plt.imshow(dmap, cmap='gray')
    plt.xlabel("decision map")
    savename = subfolder + "decision_map_2" +  ".png"
    imageio.imwrite(savename,dmap)
    plt.show()
          

    fusion = np.zeros((rows,columns))
    for i in range(R):
        stack_copy = np.copy(stack[i,:,:])
        factor = mapa == i
        fusion = fusion + np.multiply(factor,stack_copy)
    
    # show fusion
    plt.figure(figsize =(6,6))
    fusion = np.uint8(fusion)
    plt.imshow(fusion, cmap='gray')
    plt.xlabel("fusion")
    savename = subfolder + "fusion_2" +  ".png"
    imageio.imwrite(savename,fusion)
    plt.show()
    
    return entropy, mapa, fusion


def wigner_frequencies(distribution):
    """
    Starting from the pseudo-Wigner distribution (distribution) of the
    input test image, this function gives a visualization of the frequency
    components of such distribution
    """
    rows = distribution.shape[1]
    columns = distribution.shape[2]
    layers = distribution.shape[0]
    frequencies = np.zeros([layers,rows,columns])
    for layer in range(layers):
        frequency = distribution[layer,:,:]
        min_val =np.amin(frequency)
        frequency = frequency - min_val
        max_val = np.amax(frequency)
        frequency = (1/max_val)*frequency
        frequency = np.uint8(255*frequency)
        frequencies[layer,:,:]= frequency
    return frequencies 

def plot_frequencies(frequencies,angle,entropy):
    layers = frequencies.shape[0]
    rows = frequencies.shape[1]
    columns = frequencies.shape[2]
    total = rows*columns
    num_bins = 256
    # the second half of the histograms are removed due to symmetry
    limit = int(layers/2+1)
    x =np.zeros((layers,total))
    histogram = np.zeros((limit,num_bins))

    plt.figure()
    for k in range(limit):
        layer = np.copy(frequencies[k,:,:])
        x[k,:] = np.reshape(layer,total)
        plt.hist(x[k,:],num_bins,normed = True)
        lema = 'freq. hist. of the image, '+'angle = '+ str(angle) + ', entropy =  %.4f ' % entropy
        
        y = np.copy(x[k,:])
        H = np.histogram(y,bins = num_bins, normed = True)
        histogramx = np.copy(H[0])
        histogram[k,:] = histogramx
        positions = np.copy(H[1])
        
    plt.title(lema)
    return histogram,limit
    
def times_values_entropy(times,origin,test_image,seq_length):
    for k in range(times):
        
        # calculate Wigner distribution of test image
        angle = k*(180/times) + origin
        angle_str = str(k)
        distribution = layer_wigner_distribution(test_image,seq_length,angle)
        
        # entropy
        order = 3
        entropy_pixelwise = renyi_entropy(distribution,order)
        entropy = np.mean(entropy_pixelwise)
        if k == 0:
            multi_entropy = np.copy(entropy)
        else:
            multi_entropy = np.append(multi_entropy,np.copy(entropy))
        msg = 'angle = ' + str(angle)
        
    return multi_entropy

def initial_estimation(multi_entropy):
    eps = np.finfo(float).eps
    alpha = math.pi/8
    theta = np.array([alpha, 3*alpha, 5*alpha, 7*alpha])
    x11 = multi_entropy[0]*math.cos(theta[0])
    x12 = multi_entropy[0]*math.sin(theta[0])
    x21 = multi_entropy[1]*math.cos(theta[1])
    x22 = multi_entropy[1]*math.sin(theta[1])
    x31 = multi_entropy[2]*math.cos(theta[2])
    x32 = multi_entropy[2]*math.sin(theta[2])
    x41 = multi_entropy[3]*math.cos(theta[3])
    x42 = multi_entropy[3]*math.sin(theta[3])
    X = np.matrix([[x11, x12], [x21,x22],[x31,x32],[x41,x42]])
    U,s,V = np.linalg.svd(X)
    #S = np.matrix([[s[0],0], [0,s[1]],[0,0],[0,0]])
    #Y = np.dot(U,np.dot(S,V))
    # For row i in v and column i in u, the corresponding eigenvalue is s[i]**2.
    s2 = np.square(s)
    place = np.argmax(s2)
    ms = np.amax(s2)
    v = V[place,:]
    tanv = v[0,1]/(v[0,0] + eps)
    mu =np.arctan(tanv) 
    if mu < 0:
        mu = mu + math.pi
    #print('initial estimation of mu = %.4f' % mu)
    # estimation in degrees
    mu_degrees = math.degrees(mu)
    #print('initial estimation of mu (degrees) = %.4f' % mu_degrees)
    #sX = np.sum(X,0)
    #est_R = 0.25*np.linalg.norm(sX)
    est_R = np.average(multi_entropy)
    kappa = 1/(2*(1-est_R) + eps)
    #print('initial estimation of kappa = %.4f' % kappa)
    return mu,kappa

def error_eval(kappa,mu,multi_entropy):
    #DATA
    alpha = math.pi/8
    theta = np.array([alpha, 3*alpha, 5*alpha, 7*alpha])
    # Measures of entropy Ri of the image in four specific directions
    R = np.copy(multi_entropy)
    # PARAMETERS' ESTIMATION
    Ik = special.i0(kappa) 
    #Ik = 1 + math.pow(kappa,2)/4 + math.pow(kappa,4)/64 + math.pow(kappa,6)/2304
    f = (1/(2*math.pi*Ik))*np.cosh(kappa*np.cos(theta - mu))
    # LEAST SQUARES METHOD
    f2 = np.square(f)
    sf2 = np.sum(f2)
    sf = np.sum(f)
    Rf = np.multiply(R,f)
    sRf = np.sum(Rf)
    sR = np.sum(R)
    # matrix
    M = np.matrix([[sf2, sf], [sf, 4]])
    L = np.array([[sRf],[sR]])
    # inverse
    IM = np.linalg.inv(M)
    # resulution
    AB = np.dot(IM,L)
    # NORMALIZED VALUES OF ESTIMATED ENTROPY
    P = np.multiply(AB[0,0],f) + AB[1,0]
    # FIGURE OF MERIT ( ERROR)
    mode = 1
    if mode == 1:
        # 1) through comparation of values
        D1 = np.subtract(multi_entropy,P)
        S =  np.linalg.norm(D1)
    elif mode == 2:
        # 2) through fitness of the coefficients 
        V = np.array([[1],[0]])
        D2 = np.subtract(AB,V)
        S = np.linalg.norm(D2)
    
    
     
    return S,P,AB

def distr_frequencies(frequencies):
    layers = frequencies.shape[0]
    rows = frequencies.shape[1]
    columns = frequencies.shape[2]
    total = rows*columns
    num_bins = 256
    limit = int(layers/2+1)
    freq_distribution =np.zeros((limit,total))
    for k in range(limit):
        layer = np.copy(frequencies[k,:,:])
        freq_distribution[k,:] = np.reshape(layer,total)
    return freq_distribution

def image_histogram(test_image,seq_length):
    #seq_length = 9
    times = 4
    origin = 22.5
    H_points = 16
    # calculate multi-entropy y orientations: 22.5, 67.5, 112.5 and 157.5 degrees
    multi_entropy = times_values_entropy(times,origin,test_image,seq_length)
    #print('multi_entropy: ',multi_entropy)
    # calculate concentration parameter k and orientation mu of von Mises distribution
    mu,kappa = initial_estimation(multi_entropy)
    #print('kappa = %.4f' % kappa, 'mu = %.4f' % mu)
    # calculate entropy of test image in mu direction
    mu_degrees = math.degrees(mu)
    mu_times = 1
    mu_origin = mu_degrees
    mu_entropy = times_values_entropy(mu_times,mu_origin,test_image,seq_length)
    #print('entropy in mu direction = ',mu_entropy)
    # frequency histograms in mu direction
    angle_mu = mu_degrees
    distribution = layer_wigner_distribution(test_image,seq_length,angle_mu)
    frequencies = wigner_frequencies(distribution)
    freq_distribution = distr_frequencies(frequencies)
    fds= freq_distribution.shape[0]
    hist = np.zeros((fds,H_points))
    for k in range(fds):
        line = np.copy(freq_distribution[k,:])
        histx,bin_edg = np.histogram(line, bins = np.arange(H_points+1),  normed=True)
        bins = bin_edg[:-1]
        hist[k,:] = histx
    return hist,kappa,mu,mu_degrees,mu_entropy

def shannon_entropy(test_image):
    eps = np.finfo(float).eps
    (H,edg) = np.histogram(test_image,bins = 256)
    S = np.sum(H)
    H = (1/S)*H
    H1 = np.log2(H+eps)
    Sha = np.multiply(H,H1)
    S_entropy = -np.sum(Sha) 
    return S_entropy

def tamura_coarseness(test_image):
    ro = np.size(test_image,0)
    co = np.size(test_image,1)
    la = 6
    #print('processing image: ', name)
    # Tamura's coarseness calculation
    # 1) regional average filters of size k = 1, 2, ... 6, i.e.: window size: 1x1, 2x2, 4x4,8x8, 16x16, 32x32 etc.
    Eh = np.zeros(((la,ro,co)))
    Ev = np.zeros(((la,ro,co)))
    Sbest = np.zeros((ro,co))
    for p in range(6):
        if p == 0:
            Eh[p,:,:] = test_image
            Ev[p,:,:] = test_image
        else:
            p2 = np.power(2,p)
            mask = (1/np.square(p2))*np.ones((p2,p2))
            A = signal.convolve2d(test_image, mask, boundary='symm', mode='same')
            for r in range(0,ro-p2):
                for s in range(0,co-p2):
                    Eh[p,r,s] = np.absolute(A[r,s] - A[r,s+p2])
                    Ev[p,r,s] = np.absolute(A[r,s] - A[r+p2,s])
    # determine maximum values        
    Sh_best = np.amax(Eh,0)
    Sh_arg_best = np.argmax(Eh,0)
    Sv_best = np.amax(Ev,0)
    Sv_arg_best = np.argmax(Ev,0)
    for i in range(ro):
        for j in range(co):
            if Sh_best[i,j] > Sv_best[i,j]:
                Sbest[i,j] = np.power(2,Sh_arg_best[i,j])
            else:
                Sbest[i,j] = np.power(2,Sv_arg_best[i,j])
                
    coarseness = np.sum(Sbest)/(ro*co) #SomeFunctionOf(test_image)
    return coarseness

def tamura_contrast(test_image):
    eps = 0.0001
    # reshape image into 1D array
    ro = np.size(test_image,0)
    co = np.size(test_image,1)
    N = ro*co
    array = np.reshape(test_image,N)
    # stardard deviation
    dev = np.std(array)
    #print('standard deviation: ' + str(dev) )
    # kurtosis
    kur = stats.kurtosis(array,fisher=True, bias=True, nan_policy='omit')
    #print('kurtosis: ' + str(kur))
    # rise kurtosis to 0.25 power
    if kur < 0:
        kur = np.absolute(kur)
        kur025 = -np.power(kur,0.25)
    else:
        kur025 = np.power(kur,0.25)
    # Tamura's contrast
    if dev == 0:
        contrast = 0
    else:
        kur025 = kur025 + eps
        contrast = np.divide(dev,kur025)
    return contrast

def von_mises_kappa_parameter(test_image,m,n):
    MN = np.shape(test_image)
    M = MN[0]
    N = MN[1]
    p = M%m
    q = N%n
    M1 = M - p
    N1 = N - q
    X1 = test_image[0:M-p,0:N-q]
    I = int(M1/m)
    J = int(N1/n)
    K = int(m*n)
    block = np.zeros(((I,J)))
    mu = np.zeros((K))
    kappa = np.zeros((K))
    
    k = 0
    for i in range(m-1):
        for j in range(n-1):
            # take a block from the input image
            block = np.copy(X1[i*I:(i+1)*I,j*J:(j+1)*J])
            k = k + 1
            # Compute entropy in the four representative directions
            seq_length = 9
            times = 4
            origin = 22.5
            Q = times_values_entropy(times,origin,block,seq_length)
            # compute von Mises distribution characteristic parameters
            mu[k],kappa[k] = initial_estimation(Q)
    kappa_var = np.var(kappa)
    kappa_mean = np.mean(kappa)
    return kappa_mean,kappa_var
    






